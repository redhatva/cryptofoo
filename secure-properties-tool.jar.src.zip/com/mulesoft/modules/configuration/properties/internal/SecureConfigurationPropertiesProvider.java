/*     */ package com.mulesoft.modules.configuration.properties.internal;
/*     */ 
/*     */ import com.mulesoft.modules.configuration.properties.api.EncryptionAlgorithm;
/*     */ import com.mulesoft.modules.configuration.properties.api.EncryptionMode;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Base64;
/*     */ import java.util.Optional;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.mule.encryption.exception.MuleEncryptionException;
/*     */ import org.mule.runtime.api.component.location.ComponentLocation;
/*     */ import org.mule.runtime.config.api.dsl.model.ResourceProvider;
/*     */ import org.mule.runtime.config.api.dsl.model.properties.ConfigurationProperty;
/*     */ import org.mule.runtime.config.api.dsl.model.properties.DefaultConfigurationPropertiesProvider;
/*     */ import org.mule.runtime.core.api.util.IOUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecureConfigurationPropertiesProvider
/*     */   extends DefaultConfigurationPropertiesProvider
/*     */ {
/*     */   private static final String SECURE_PREFIX = "secure::";
/*  44 */   private static final Pattern SECURE_PATTERN = Pattern.compile("\\$\\{secure::[^}]*}");
/*     */   
/*     */   private final EncryptionAlgorithm algorithm;
/*     */   
/*     */   private final EncryptionMode mode;
/*     */   
/*     */   private final boolean fileLevelEncryption;
/*     */   
/*     */   private final SecurePropertyPlaceholderModule securePropertyPlaceholderModule;
/*     */   
/*     */   public SecureConfigurationPropertiesProvider(ResourceProvider resourceProvider, String file, EncryptionAlgorithm algorithm, String key, EncryptionMode mode, String encoding, boolean fileLevelEncryption, boolean useRandomIVs) {
/*  55 */     super(file, encoding, resourceProvider);
/*     */     
/*  57 */     this.algorithm = algorithm;
/*  58 */     this.mode = mode;
/*  59 */     this.fileLevelEncryption = fileLevelEncryption;
/*     */     
/*  61 */     this.securePropertyPlaceholderModule = new SecurePropertyPlaceholderModule(algorithm, mode, key, useRandomIVs);
/*     */   }
/*     */ 
/*     */   
/*     */   public Optional<ConfigurationProperty> getConfigurationProperty(String configurationAttributeKey) {
/*  66 */     if (configurationAttributeKey.startsWith("secure::")) {
/*  67 */       String effectiveKey = configurationAttributeKey.substring("secure::".length());
/*     */       
/*  69 */       final ConfigurationProperty originalConfigurationProperty = (ConfigurationProperty)this.configurationAttributes.get(effectiveKey);
/*  70 */       if (originalConfigurationProperty == null) {
/*  71 */         return Optional.empty();
/*     */       }
/*  73 */       String originalString = (String)originalConfigurationProperty.getRawValue();
/*  74 */       String encryptedValue = originalString.substring(originalConfigurationProperty.getKey().length() + 1, originalString
/*  75 */           .length() - this.algorithm.name().length() - this.mode.name().length() - 2);
/*     */       
/*  77 */       final String decryptedValue = resolveInnerProperties(this.securePropertyPlaceholderModule.convertPropertyValue(encryptedValue));
/*  78 */       return Optional.of(new ConfigurationProperty()
/*     */           {
/*     */             public Object getSource()
/*     */             {
/*  82 */               return originalConfigurationProperty.getSource();
/*     */             }
/*     */ 
/*     */             
/*     */             public Object getRawValue() {
/*  87 */               return decryptedValue;
/*     */             }
/*     */ 
/*     */             
/*     */             public String getKey() {
/*  92 */               return originalConfigurationProperty.getKey();
/*     */             }
/*     */           });
/*     */     } 
/*  96 */     return Optional.empty();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDescription() {
/* 102 */     ComponentLocation location = (ComponentLocation)getAnnotation(LOCATION_KEY);
/* 103 */     return String.format("<secure-properties file=\"%s\"> - file: %s, line number: %s", new Object[] { this.fileLocation, location
/* 104 */           .getFileName().orElse("unknown"), location
/* 105 */           .getLineInFile().map(String::valueOf).orElse("unknown") });
/*     */   }
/*     */ 
/*     */   
/*     */   protected String createValue(String key, String value) {
/* 110 */     return String.format("%s:%s:%s:%s", new Object[] { key, value, this.algorithm, this.mode });
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputStream getResourceInputStream(String file) throws IOException {
/* 115 */     InputStream originalStream = super.getResourceInputStream(file);
/* 116 */     if (!this.fileLevelEncryption) {
/* 117 */       return originalStream;
/*     */     }
/*     */ 
/*     */     
/* 121 */     byte[] content = IOUtils.toByteArray(originalStream);
/*     */     try {
/* 123 */       return new ByteArrayInputStream(this.securePropertyPlaceholderModule.decrypt(Base64.getDecoder().decode(content)));
/* 124 */     } catch (MuleEncryptionException e) {
/* 125 */       throw new IOException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private String resolveInnerProperties(String decryptedValue) {
/* 130 */     Matcher m = SECURE_PATTERN.matcher(decryptedValue);
/* 131 */     while (m.find()) {
/* 132 */       String secureInnerProperty = m.group();
/*     */       
/* 134 */       Optional<ConfigurationProperty> innerProperty = getConfigurationProperty(secureInnerProperty);
/* 135 */       if (innerProperty.isPresent()) {
/* 136 */         String innerPropertyValue = (String)((ConfigurationProperty)innerProperty.get()).getRawValue();
/* 137 */         decryptedValue = decryptedValue.replaceAll(secureInnerProperty, innerPropertyValue);
/*     */       } 
/*     */     } 
/* 140 */     return decryptedValue;
/*     */   }
/*     */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/internal/SecureConfigurationPropertiesProvider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */