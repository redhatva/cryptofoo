/*    */ package com.mulesoft.modules.configuration.properties.internal.keyfactories;
/*    */ 
/*    */ import java.security.Key;
/*    */ import java.security.KeyFactory;
/*    */ import java.security.spec.PKCS8EncodedKeySpec;
/*    */ import java.security.spec.X509EncodedKeySpec;
/*    */ import org.mule.encryption.key.EncryptionKeyFactory;
/*    */ import org.mule.runtime.core.api.util.Base64;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsymmetricEncryptionKeyFactory
/*    */   implements EncryptionKeyFactory
/*    */ {
/*    */   private String algorithm;
/*    */   private byte[] key;
/*    */   
/*    */   public AsymmetricEncryptionKeyFactory(String algorithm, String key) {
/* 29 */     validateKey(key);
/* 30 */     this.algorithm = algorithm;
/* 31 */     this.key = Base64.decode(key);
/*    */   }
/*    */ 
/*    */   
/*    */   public Key encryptionKey() {
/* 36 */     PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(this.key);
/*    */     try {
/* 38 */       KeyFactory kf = KeyFactory.getInstance(this.algorithm);
/* 39 */       return kf.generatePrivate(spec);
/* 40 */     } catch (Exception e) {
/* 41 */       throw new RuntimeException("Could not build the Encryption key", e);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public Key decryptionKey() {
/* 47 */     X509EncodedKeySpec spec = new X509EncodedKeySpec(this.key);
/*    */     try {
/* 49 */       KeyFactory kf = KeyFactory.getInstance(this.algorithm);
/* 50 */       return kf.generatePublic(spec);
/* 51 */     } catch (Exception e) {
/* 52 */       throw new RuntimeException("Could not build the descryption key", e);
/*    */     } 
/*    */   }
/*    */   
/*    */   private void validateKey(String key) {
/* 57 */     if (key == null)
/* 58 */       throw new IllegalArgumentException("If keystore is not defined then the key is considered to be an encryption key in Base64 encoding"); 
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/internal/keyfactories/AsymmetricEncryptionKeyFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */