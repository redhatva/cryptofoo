/*    */ package com.mulesoft.modules.configuration.properties.internal.keyfactories;
/*    */ 
/*    */ import java.security.Key;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ import org.mule.encryption.key.SymmetricKeyFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SymmetricEncryptionKeyFactory
/*    */   implements SymmetricKeyFactory
/*    */ {
/*    */   private String algorithm;
/*    */   private byte[] key;
/*    */   
/*    */   public SymmetricEncryptionKeyFactory(String algorithm, String key) {
/* 26 */     validateKey(key);
/* 27 */     this.algorithm = algorithm;
/* 28 */     this.key = key.getBytes();
/*    */   }
/*    */ 
/*    */   
/*    */   public Key encryptionKey() {
/* 33 */     return new SecretKeySpec(this.key, this.algorithm);
/*    */   }
/*    */   
/*    */   private void validateKey(String key) {
/* 37 */     if (key == null)
/* 38 */       throw new IllegalArgumentException("If keystore is not defined then the key is considered to be an encryption key in Base64 encoding"); 
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/internal/keyfactories/SymmetricEncryptionKeyFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */