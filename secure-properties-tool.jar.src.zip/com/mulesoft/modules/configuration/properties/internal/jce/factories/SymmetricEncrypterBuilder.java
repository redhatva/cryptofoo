/*    */ package com.mulesoft.modules.configuration.properties.internal.jce.factories;
/*    */ 
/*    */ import com.mulesoft.modules.configuration.properties.api.EncrypterBuilder;
/*    */ import com.mulesoft.modules.configuration.properties.api.EncryptionAlgorithm;
/*    */ import com.mulesoft.modules.configuration.properties.internal.jce.EncryptionPadding;
/*    */ import com.mulesoft.modules.configuration.properties.internal.keyfactories.SymmetricEncryptionKeyFactory;
/*    */ import org.mule.encryption.Encrypter;
/*    */ import org.mule.encryption.jce.JCEEncrypter;
/*    */ import org.mule.encryption.key.EncryptionKeyFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SymmetricEncrypterBuilder
/*    */   extends EncrypterBuilder
/*    */ {
/*    */   private EncryptionAlgorithm encryptionAlgorithm;
/*    */   
/*    */   public SymmetricEncrypterBuilder(EncryptionAlgorithm encryptionAlgorithm) {
/* 23 */     this.encryptionAlgorithm = encryptionAlgorithm;
/*    */   }
/*    */ 
/*    */   
/*    */   public Encrypter build() {
/* 28 */     return (Encrypter)new JCEEncrypter(this.encryptionAlgorithm.name() + "/" + this.mode.name() + "/" + EncryptionPadding.PKCS5Padding.name(), null, (EncryptionKeyFactory)new SymmetricEncryptionKeyFactory(this.encryptionAlgorithm
/* 29 */           .name(), this.key), this.useRandomIVs);
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/internal/jce/factories/SymmetricEncrypterBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */