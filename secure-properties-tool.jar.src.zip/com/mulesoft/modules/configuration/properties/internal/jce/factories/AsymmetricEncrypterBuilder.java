/*    */ package com.mulesoft.modules.configuration.properties.internal.jce.factories;
/*    */ 
/*    */ import com.mulesoft.modules.configuration.properties.api.EncrypterBuilder;
/*    */ import com.mulesoft.modules.configuration.properties.api.EncryptionAlgorithm;
/*    */ import com.mulesoft.modules.configuration.properties.api.EncryptionMode;
/*    */ import com.mulesoft.modules.configuration.properties.internal.jce.EncryptionPadding;
/*    */ import com.mulesoft.modules.configuration.properties.internal.keyfactories.AsymmetricEncryptionKeyFactory;
/*    */ import org.mule.encryption.Encrypter;
/*    */ import org.mule.encryption.jce.JCEEncrypter;
/*    */ import org.mule.encryption.key.EncryptionKeyFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AsymmetricEncrypterBuilder
/*    */   extends EncrypterBuilder
/*    */ {
/*    */   public Encrypter build() {
/* 23 */     return (Encrypter)new JCEEncrypter(EncryptionAlgorithm.RSA.name() + "/" + EncryptionMode.ECB.name() + "/" + EncryptionPadding.PKCS1PADDING.name(), null, (EncryptionKeyFactory)new AsymmetricEncryptionKeyFactory(EncryptionAlgorithm.RSA
/* 24 */           .name(), this.key), false);
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/internal/jce/factories/AsymmetricEncrypterBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */