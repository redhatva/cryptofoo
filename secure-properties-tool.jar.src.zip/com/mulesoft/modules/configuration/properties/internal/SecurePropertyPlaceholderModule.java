/*     */ package com.mulesoft.modules.configuration.properties.internal;
/*     */ 
/*     */ import com.mulesoft.modules.configuration.properties.api.EncryptionAlgorithm;
/*     */ import com.mulesoft.modules.configuration.properties.api.EncryptionMode;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.mule.encryption.Encrypter;
/*     */ import org.mule.encryption.exception.MuleEncryptionException;
/*     */ import org.mule.encryption.exception.MuleInvalidAlgorithmConfigurationException;
/*     */ import org.mule.runtime.core.api.util.Base64;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurePropertyPlaceholderModule
/*     */ {
/*     */   private static final String FIPS_SECURITY_MODEL = "fips140-2";
/*     */   private static final String PROPERTY_SECURITY_MODEL = "mule.security.model";
/*     */   private static final String FIPS_MODE_MESSAGE = "You're running in FIPS mode  so please verify that the algorithm is compliant with FIPS.";
/*     */   private Encrypter encrypter;
/*     */   private EncryptionAlgorithm encryptionAlgorithm;
/*     */   private EncryptionMode encryptionMode;
/*     */   private boolean useRandomIVs;
/*     */   
/*     */   public SecurePropertyPlaceholderModule(EncryptionAlgorithm algorithm, EncryptionMode mode, String key, boolean useRandomIVs) {
/*  58 */     this.encryptionAlgorithm = algorithm;
/*  59 */     this.encryptionMode = mode;
/*  60 */     this.useRandomIVs = useRandomIVs;
/*  61 */     buildEncrypter(key);
/*     */   }
/*     */   
/*     */   private void buildEncrypter(String key) {
/*  65 */     this
/*  66 */       .encrypter = this.encryptionAlgorithm.getBuilder().using(this.encryptionMode).forKey(readEnvironmentalProperties(key)).useRandomIVs(this.useRandomIVs).build();
/*     */   }
/*     */   
/*     */   private static boolean isFipsEnabled() {
/*  70 */     return "fips140-2".equals(System.getProperty("mule.security.model"));
/*     */   }
/*     */   
/*     */   public byte[] decrypt(byte[] payload) throws MuleEncryptionException {
/*     */     try {
/*  75 */       return this.encrypter.decrypt(payload);
/*  76 */     } catch (MuleInvalidAlgorithmConfigurationException e) {
/*  77 */       if (isFipsEnabled()) {
/*  78 */         throw new MuleEncryptionException(e.getMessage(), new NotSupportedInFipsModeException("You're running in FIPS mode  so please verify that the algorithm is compliant with FIPS.", e));
/*     */       }
/*     */       
/*  81 */       throw e;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setKey(String key) {
/*  86 */     buildEncrypter(key);
/*     */   }
/*     */   
/*     */   public String convertPropertyValue(String originalValue) {
/*  90 */     if (!originalValue.startsWith("![") || !originalValue.endsWith("]")) {
/*  91 */       return originalValue;
/*     */     }
/*     */     
/*  94 */     String propertyKey = originalValue.substring(2, originalValue.length() - 1);
/*     */     
/*     */     try {
/*  97 */       return new String(decrypt(Base64.decode(propertyKey)));
/*  98 */     } catch (MuleEncryptionException e) {
/*  99 */       throw new RuntimeException(e);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String readEnvironmentalProperties(String text) {
/* 104 */     Pattern propertyPatter = Pattern.compile("\\$\\{([^}]+)}");
/* 105 */     Matcher propertyMatcher = propertyPatter.matcher(text);
/* 106 */     String modifiedText = text;
/* 107 */     while (propertyMatcher.find()) {
/* 108 */       String property = propertyMatcher.group(1);
/* 109 */       modifiedText = replaceProperty(modifiedText, property);
/*     */     } 
/*     */     
/* 112 */     return modifiedText;
/*     */   }
/*     */   
/*     */   private String replaceProperty(String modifiedText, String property) {
/* 116 */     String propertyValue = System.getProperty(property);
/* 117 */     checkForPropertyExistence(property, propertyValue);
/* 118 */     propertyValue = convertPropertyValue(propertyValue);
/* 119 */     String pattern = "\\$\\{(" + property + ")}";
/* 120 */     Pattern replacement = Pattern.compile(pattern);
/* 121 */     Matcher replacementMatcher = replacement.matcher(modifiedText);
/* 122 */     replacementMatcher.find();
/* 123 */     return replacementMatcher.replaceAll(Matcher.quoteReplacement(propertyValue));
/*     */   }
/*     */   
/*     */   private void checkForPropertyExistence(String property, String propertyValue) {
/* 127 */     if (propertyValue == null)
/* 128 */       throw new RuntimeException("Property " + property + " could not be found"); 
/*     */   }
/*     */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/internal/SecurePropertyPlaceholderModule.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */