/*    */ package com.mulesoft.modules.configuration.properties.internal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NotSupportedInFipsModeException
/*    */   extends Exception
/*    */ {
/*    */   public NotSupportedInFipsModeException(String s) {
/* 12 */     super(s);
/*    */   }
/*    */   
/*    */   public NotSupportedInFipsModeException(String s, Exception e) {
/* 16 */     super(s, e);
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/internal/NotSupportedInFipsModeException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */