/*    */ package com.mulesoft.modules.configuration.properties.api;
/*    */ 
/*    */ import org.mule.metadata.api.ClassTypeLoader;
/*    */ import org.mule.metadata.api.builder.BaseTypeBuilder;
/*    */ import org.mule.metadata.api.model.MetadataFormat;
/*    */ import org.mule.metadata.api.model.MetadataType;
/*    */ import org.mule.runtime.api.meta.Category;
/*    */ import org.mule.runtime.api.meta.ExpressionSupport;
/*    */ import org.mule.runtime.api.meta.model.declaration.fluent.ConfigurationDeclarer;
/*    */ import org.mule.runtime.api.meta.model.declaration.fluent.ExtensionDeclarer;
/*    */ import org.mule.runtime.api.meta.model.declaration.fluent.OptionalParameterDeclarer;
/*    */ import org.mule.runtime.api.meta.model.declaration.fluent.ParameterGroupDeclarer;
/*    */ import org.mule.runtime.api.meta.model.display.DisplayModel;
/*    */ import org.mule.runtime.api.meta.model.display.PathModel;
/*    */ import org.mule.runtime.extension.api.declaration.type.ExtensionsTypeLoaderFactory;
/*    */ import org.mule.runtime.extension.api.loader.ExtensionLoadingContext;
/*    */ import org.mule.runtime.extension.api.loader.ExtensionLoadingDelegate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecureConfigPropertiesExtensionLoadingDelegate
/*    */   implements ExtensionLoadingDelegate
/*    */ {
/*    */   public static final String EXTENSION_NAME = "Secure Properties";
/*    */   public static final String VERSION = "1.2.2";
/*    */   
/*    */   public void accept(ExtensionDeclarer extensionDeclarer, ExtensionLoadingContext context) {
/* 51 */     ConfigurationDeclarer configurationDeclarer = extensionDeclarer.named("Secure Properties").describedAs("Crafted Config Properties Extension").withCategory(Category.SELECT).onVersion("1.2.2").fromVendor("Mulesoft").withConfig("config");
/*    */     
/* 53 */     ParameterGroupDeclarer defaultParameterGroup = configurationDeclarer.onDefaultParameterGroup();
/* 54 */     defaultParameterGroup
/* 55 */       .withRequiredParameter("file").ofType((MetadataType)BaseTypeBuilder.create(MetadataFormat.JAVA).stringType().build())
/* 56 */       .withExpressionSupport(ExpressionSupport.NOT_SUPPORTED)
/* 57 */       .withDisplayModel(DisplayModel.builder().path(new PathModel(PathModel.Type.FILE, false, PathModel.Location.EMBEDDED, new String[] { "yaml", "properties"
/* 58 */             })).build())
/* 59 */       .describedAs(" The location of the file with the secure configuration properties to use. It may be a location in the classpath or an absolute location. \nThe file location value may also contains references to properties that will only be resolved based on system properties or properties set at deployment time.");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 65 */     defaultParameterGroup
/* 66 */       .withRequiredParameter("key").ofType((MetadataType)BaseTypeBuilder.create(MetadataFormat.JAVA).stringType().build());
/* 67 */     ((OptionalParameterDeclarer)defaultParameterGroup.withOptionalParameter("fileLevelEncryption")
/* 68 */       .ofType((MetadataType)BaseTypeBuilder.create(MetadataFormat.JAVA).booleanType().build()))
/* 69 */       .defaultingTo(Boolean.FALSE);
/* 70 */     defaultParameterGroup.withOptionalParameter("encoding").ofType((MetadataType)BaseTypeBuilder.create(MetadataFormat.JAVA).stringType().build());
/*    */ 
/*    */     
/* 73 */     ParameterGroupDeclarer parameterGroupDeclarer = configurationDeclarer.onParameterGroup("encrypt").withDslInlineRepresentation(true);
/*    */     
/* 75 */     ClassTypeLoader typeLoader = ExtensionsTypeLoaderFactory.getDefault().createTypeLoader();
/* 76 */     ((OptionalParameterDeclarer)parameterGroupDeclarer.withOptionalParameter("algorithm").ofType(typeLoader.load(EncryptionAlgorithm.class)))
/* 77 */       .defaultingTo(EncryptionAlgorithm.AES);
/* 78 */     ((OptionalParameterDeclarer)parameterGroupDeclarer.withOptionalParameter("mode").ofType(typeLoader.load(EncryptionMode.class)))
/* 79 */       .defaultingTo(EncryptionMode.CBC);
/* 80 */     ((OptionalParameterDeclarer)((OptionalParameterDeclarer)((OptionalParameterDeclarer)parameterGroupDeclarer.withOptionalParameter("useRandomIVs")
/* 81 */       .ofType((MetadataType)BaseTypeBuilder.create(MetadataFormat.JAVA).booleanType().build()))
/* 82 */       .withDisplayModel(DisplayModel.builder().displayName("Use random IVs")
/* 83 */         .summary("Use random initial vectors (IVs). In case of decryption, it assumes IV is prepended on the ciphertext.")
/* 84 */         .build()))
/* 85 */       .withExpressionSupport(ExpressionSupport.NOT_SUPPORTED))
/* 86 */       .defaultingTo(Boolean.FALSE);
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/api/SecureConfigPropertiesExtensionLoadingDelegate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */