package com.mulesoft.modules.configuration.properties.api;

public interface EncrypterBuilderFactory {
  EncrypterBuilder createFor(EncryptionAlgorithm paramEncryptionAlgorithm);
}


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/api/EncrypterBuilderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */