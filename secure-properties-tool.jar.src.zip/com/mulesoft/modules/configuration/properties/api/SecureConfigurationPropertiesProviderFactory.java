/*     */ package com.mulesoft.modules.configuration.properties.api;
/*     */ 
/*     */ import com.mulesoft.modules.configuration.properties.internal.SecureConfigurationPropertiesProvider;
/*     */ import java.util.List;
/*     */ import org.mule.encryption.jce.JCE;
/*     */ import org.mule.runtime.api.component.ComponentIdentifier;
/*     */ import org.mule.runtime.api.exception.MuleRuntimeException;
/*     */ import org.mule.runtime.api.i18n.I18nMessageFactory;
/*     */ import org.mule.runtime.api.util.Preconditions;
/*     */ import org.mule.runtime.config.api.dsl.model.ConfigurationParameters;
/*     */ import org.mule.runtime.config.api.dsl.model.ResourceProvider;
/*     */ import org.mule.runtime.config.api.dsl.model.properties.ConfigurationPropertiesProvider;
/*     */ import org.mule.runtime.config.api.dsl.model.properties.ConfigurationPropertiesProviderFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecureConfigurationPropertiesProviderFactory
/*     */   implements ConfigurationPropertiesProviderFactory
/*     */ {
/*     */   public static final String EXTENSION_NAMESPACE = "secure-properties";
/*     */   public static final String SECURE_CONFIGURATION_PROPERTIES_ELEMENT = "config";
/*  44 */   public static final ComponentIdentifier SECURE_CONFIGURATION_PROPERTIES = ComponentIdentifier.builder().namespace("secure-properties").name("config").build();
/*     */ 
/*     */   
/*     */   private static final String SHORT_KEY_MESSAGE = "You need to increment your key size. The minimum allowed key size is: %d, but your key size is: %d";
/*     */   
/*     */   private static final String LONG_KEY_MESSAGE = "Your key size exceeds the maximum allowed key size in your JVM. The maximum allowed key size is: %d, but your key size is: %d.";
/*     */   
/*     */   private static final String INSTALL_JCE_MESSAGE = "You need to install the Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files";
/*     */ 
/*     */   
/*     */   public ComponentIdentifier getSupportedComponentIdentifier() {
/*  55 */     return SECURE_CONFIGURATION_PROPERTIES;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SecureConfigurationPropertiesProvider createProvider(ConfigurationParameters parameters, ResourceProvider externalResourceProvider) {
/*  61 */     String file = parameters.getStringParameter("file");
/*  62 */     Preconditions.checkArgument((file != null), "Required attribute 'file' of 'secure-configuration-properties' not found");
/*     */ 
/*     */     
/*  65 */     String key = parameters.getStringParameter("key");
/*  66 */     Preconditions.checkArgument((key != null), "Required attribute 'key' of 'secure-configuration-properties' not found");
/*     */ 
/*     */     
/*  69 */     String encoding = getFileEncoding(parameters);
/*     */ 
/*     */     
/*  72 */     ComponentIdentifier encryptComponentIdentifier = ComponentIdentifier.builder().namespace("secure-properties").name("encrypt").build();
/*     */     
/*  74 */     EncryptionAlgorithm algorithm = getAlgorithm(parameters.getComplexConfigurationParameter(encryptComponentIdentifier));
/*  75 */     EncryptionMode mode = getMode(parameters.getComplexConfigurationParameter(encryptComponentIdentifier));
/*  76 */     boolean fileLevelEncryption = getFileLevelEncryption(parameters);
/*     */     
/*  78 */     validateKeyLength(key, algorithm);
/*     */     
/*  80 */     boolean useRandomIVs = getUseRandomIVs(parameters.getComplexConfigurationParameter(encryptComponentIdentifier));
/*     */     
/*  82 */     return new SecureConfigurationPropertiesProvider(externalResourceProvider, file, algorithm, key, mode, encoding, fileLevelEncryption, useRandomIVs);
/*     */   }
/*     */ 
/*     */   
/*     */   private EncryptionAlgorithm getAlgorithm(List<ConfigurationParameters> encryptionParameters) {
/*  87 */     return EncryptionAlgorithm.valueOf(getProperty(encryptionParameters, "algorithm", EncryptionAlgorithm.AES.name()));
/*     */   }
/*     */   
/*     */   private EncryptionMode getMode(List<ConfigurationParameters> encryptionParameters) {
/*  91 */     return EncryptionMode.valueOf(getProperty(encryptionParameters, "mode", EncryptionMode.CBC.name()));
/*     */   }
/*     */   
/*     */   private boolean getFileLevelEncryption(ConfigurationParameters parameters) {
/*     */     try {
/*  96 */       return Boolean.valueOf(parameters.getStringParameter("fileLevelEncryption")).booleanValue();
/*  97 */     } catch (Exception e) {
/*  98 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getFileEncoding(ConfigurationParameters parameters) {
/* 103 */     return parameters.getStringParameter("encoding");
/*     */   }
/*     */   
/*     */   private String getProperty(List<ConfigurationParameters> encryptionParameters, String property, String defaultValue) {
/* 107 */     if (encryptionParameters.size() != 1) {
/* 108 */       return defaultValue;
/*     */     }
/*     */     
/* 111 */     String propertyValue = ((ConfigurationParameters)encryptionParameters.get(0)).getStringParameter(property);
/* 112 */     return (propertyValue != null) ? propertyValue : defaultValue;
/*     */   }
/*     */   
/*     */   private void validateKeyLength(String key, EncryptionAlgorithm algorithm) {
/* 116 */     if (key.length() > algorithm.getMaxKeySize()) {
/* 117 */       String message = String.format("Your key size exceeds the maximum allowed key size in your JVM. The maximum allowed key size is: %d, but your key size is: %d.", new Object[] { Integer.valueOf(algorithm.getMaxKeySize()), Integer.valueOf(key.length()) });
/* 118 */       if (!JCE.isJCEInstalled()) {
/* 119 */         message = message + "You need to install the Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files";
/*     */       }
/*     */       
/* 122 */       throw new MuleRuntimeException(I18nMessageFactory.createStaticMessage(message));
/* 123 */     }  if (key.length() < algorithm.getMinKeySize()) {
/* 124 */       String message = String.format("You need to increment your key size. The minimum allowed key size is: %d, but your key size is: %d", new Object[] { Integer.valueOf(algorithm.getMinKeySize()), Integer.valueOf(key.length()) });
/* 125 */       throw new MuleRuntimeException(I18nMessageFactory.createStaticMessage(message));
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean getUseRandomIVs(List<ConfigurationParameters> encryptionParameters) {
/* 130 */     return Boolean.valueOf(getProperty(encryptionParameters, "useRandomIVs", "false")).booleanValue();
/*     */   }
/*     */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/api/SecureConfigurationPropertiesProviderFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */