/*    */ package com.mulesoft.modules.configuration.properties.api;
/*    */ 
/*    */ import com.mulesoft.modules.configuration.properties.internal.jce.factories.AsymmetricEncrypterBuilder;
/*    */ import com.mulesoft.modules.configuration.properties.internal.jce.factories.SymmetricEncrypterBuilder;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import javax.crypto.Cipher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum EncryptionAlgorithm
/*    */ {
/* 41 */   RSA(16, algorithm -> new AsymmetricEncrypterBuilder()), RC6(16, algorithm -> new AsymmetricEncrypterBuilder()), RC5(16, algorithm -> new AsymmetricEncrypterBuilder()), RC2(16, algorithm -> new AsymmetricEncrypterBuilder()), XTEA(16, algorithm -> new AsymmetricEncrypterBuilder()), Twofish(16, algorithm -> new AsymmetricEncrypterBuilder()), TEA(16, algorithm -> new AsymmetricEncrypterBuilder()), Skipjack(16, algorithm -> new AsymmetricEncrypterBuilder()), Serpent(16, algorithm -> new AsymmetricEncrypterBuilder()), SEED(16, algorithm -> new AsymmetricEncrypterBuilder()), Rijndael(16, algorithm -> new AsymmetricEncrypterBuilder()), Noekeon(16, algorithm -> new AsymmetricEncrypterBuilder()), CAST6(16, algorithm -> new AsymmetricEncrypterBuilder()), CAST5(16, algorithm -> new AsymmetricEncrypterBuilder()), Camellia(16, algorithm -> new AsymmetricEncrypterBuilder()), DESede(16, algorithm -> new AsymmetricEncrypterBuilder()), DES(16, algorithm -> new AsymmetricEncrypterBuilder()), Blowfish(16, algorithm -> new AsymmetricEncrypterBuilder()), AES(16, algorithm -> new AsymmetricEncrypterBuilder());
/*    */ 
/*    */   
/*    */   private EncrypterBuilderFactory factory;
/*    */ 
/*    */ 
/*    */   
/*    */   EncryptionAlgorithm(int minSize, EncrypterBuilderFactory factory) {
/* 49 */     this.minSize = minSize;
/* 50 */     this.factory = factory;
/*    */   } private int minSize; static { AES = new EncryptionAlgorithm("AES", 0, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm)); Blowfish = new EncryptionAlgorithm("Blowfish", 1, 1, algorithm -> new SymmetricEncrypterBuilder(algorithm)); DES = new EncryptionAlgorithm("DES", 2, 8, algorithm -> new SymmetricEncrypterBuilder(algorithm)); DESede = new EncryptionAlgorithm("DESede", 3, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm)); Camellia = new EncryptionAlgorithm("Camellia", 4, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm)); CAST5 = new EncryptionAlgorithm("CAST5", 5, 1, algorithm -> new SymmetricEncrypterBuilder(algorithm)); CAST6 = new EncryptionAlgorithm("CAST6", 6, 1, algorithm -> new SymmetricEncrypterBuilder(algorithm)); Noekeon = new EncryptionAlgorithm("Noekeon", 7, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm)); Rijndael = new EncryptionAlgorithm("Rijndael", 8, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm)); SEED = new EncryptionAlgorithm("SEED", 9, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm)); Serpent = new EncryptionAlgorithm("Serpent", 10, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm)); Skipjack = new EncryptionAlgorithm("Skipjack", 11, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm)); TEA = new EncryptionAlgorithm("TEA", 12, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm)); Twofish = new EncryptionAlgorithm("Twofish", 13, 8, algorithm -> new SymmetricEncrypterBuilder(algorithm)); XTEA = new EncryptionAlgorithm("XTEA", 14, 16, algorithm -> new SymmetricEncrypterBuilder(algorithm));
/*    */     RC2 = new EncryptionAlgorithm("RC2", 15, 1, algorithm -> new SymmetricEncrypterBuilder(algorithm));
/*    */     RC5 = new EncryptionAlgorithm("RC5", 16, 1, algorithm -> new SymmetricEncrypterBuilder(algorithm));
/* 54 */     RC6 = new EncryptionAlgorithm("RC6", 17, 1, algorithm -> new SymmetricEncrypterBuilder(algorithm)); } public int getMinKeySize() { return this.minSize; }
/*    */ 
/*    */   
/*    */   public int getMaxKeySize() {
/*    */     try {
/* 59 */       return Cipher.getMaxAllowedKeyLength(name()) / 8;
/* 60 */     } catch (NoSuchAlgorithmException e) {
/* 61 */       return 0;
/*    */     } 
/*    */   }
/*    */   
/*    */   public EncrypterBuilder getBuilder() {
/* 66 */     return this.factory.createFor(this);
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/api/EncryptionAlgorithm.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */