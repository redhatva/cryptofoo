package com.mulesoft.modules.configuration.properties.api;

public final class SecureConfigurationPropertiesConstants {
  public static final String FILE_PARAMETER = "file";
  
  public static final String KEY_PARAMETER = "key";
  
  public static final String FILE_LEVEL_ENCRYPTION_PARAMETER = "fileLevelEncryption";
  
  public static final String ENCODING_PARAMETER = "encoding";
  
  public static final String ENCRYPT_PARAMETER = "encrypt";
  
  public static final String ALGORITHM_PARAMETER = "algorithm";
  
  public static final String MODE_PARAMETER = "mode";
  
  public static final String USE_RANDOM_IV_PARAMETER = "useRandomIVs";
}


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/api/SecureConfigurationPropertiesConstants.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */