/*    */ package com.mulesoft.modules.configuration.properties.api;
/*    */ 
/*    */ import org.mule.encryption.Encrypter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EncrypterBuilder
/*    */ {
/*    */   protected EncryptionMode mode;
/*    */   protected String key;
/*    */   protected boolean useRandomIVs;
/*    */   
/*    */   public EncrypterBuilder using(EncryptionMode mode) {
/* 18 */     this.mode = mode;
/* 19 */     return this;
/*    */   }
/*    */   
/*    */   public abstract Encrypter build();
/*    */   
/*    */   public EncrypterBuilder forKey(String key) {
/* 25 */     this.key = key;
/* 26 */     return this;
/*    */   }
/*    */   
/*    */   public EncrypterBuilder useRandomIVs(boolean useRandomIVs) {
/* 30 */     this.useRandomIVs = useRandomIVs;
/* 31 */     return this;
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/modules/configuration/properties/api/EncrypterBuilder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */