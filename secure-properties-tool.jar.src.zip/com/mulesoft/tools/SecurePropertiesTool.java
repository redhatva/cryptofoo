/*     */ package com.mulesoft.tools;
/*     */ 
/*     */ import com.mulesoft.modules.configuration.properties.api.EncryptionAlgorithm;
/*     */ import com.mulesoft.modules.configuration.properties.api.EncryptionMode;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.util.Base64;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.mule.encryption.Encrypter;
/*     */ import org.mule.encryption.exception.MuleEncryptionException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SecurePropertiesTool
/*     */ {
/*     */   public static final String ENCRYPTION_ACTION = "encrypt";
/*     */   public static final String DECRYPTION_ACTION = "decrypt";
/*     */   private static final String HOLE_FILE_LEVEL_TYPE = "file-level";
/*     */   private static final String FILE_TYPE = "file";
/*     */   private static final String WORD_TYPE = "string";
/*     */   private static final String YAML_FILE = ".yaml";
/*     */   private static final String PROPERTIES_FILE_SEPARATOR = "=";
/*     */   private static final String YAML_SEPARATOR = ":";
/*     */   private static final String PROPERTIES_FILE = ".properties";
/*     */   private static final char COMMENTS = '#';
/*     */   private static final char VALUE_DELIMITER = '"';
/*  42 */   private static final Pattern encryptPattern = Pattern.compile("!\\[(.*)\\]");
/*     */   private static final String USE_RANDOM_IV = "--use-random-iv";
/*     */   
/*     */   private static Encrypter createEncrypter(String algorithm, String mode, String key, boolean useRandomIVs) {
/*  46 */     return EncryptionAlgorithm.valueOf(algorithm).getBuilder().forKey(key).using(EncryptionMode.valueOf(mode)).useRandomIVs(useRandomIVs).build();
/*     */   }
/*     */   
/*     */   private static String decrypt(String value, String algorithm, String mode, String key, boolean useRandomIVs) throws MuleEncryptionException {
/*  50 */     Encrypter encrypter = createEncrypter(algorithm, mode, key, useRandomIVs);
/*  51 */     return new String(encrypter.decrypt(Base64.getDecoder().decode(value)));
/*     */   }
/*     */   
/*     */   private static String encrypt(String value, String algorithm, String mode, String key, boolean useRandomIVs) throws MuleEncryptionException {
/*  55 */     Encrypter encrypter = createEncrypter(algorithm, mode, key, useRandomIVs);
/*  56 */     return new String(Base64.getEncoder().encode(encrypter.encrypt(value.getBytes())));
/*     */   }
/*     */   
/*     */   private static byte[] decrypt(byte[] value, String algorithm, String mode, String key, boolean useRandomIVs) throws MuleEncryptionException {
/*  60 */     Encrypter encrypter = createEncrypter(algorithm, mode, key, useRandomIVs);
/*  61 */     return encrypter.decrypt(Base64.getDecoder().decode(value));
/*     */   }
/*     */   
/*     */   private static byte[] encrypt(byte[] value, String algorithm, String mode, String key, boolean useRandomIVs) throws MuleEncryptionException {
/*  65 */     Encrypter encrypter = createEncrypter(algorithm, mode, key, useRandomIVs);
/*  66 */     return Base64.getEncoder().encode(encrypter.encrypt(value));
/*     */   }
/*     */   
/*     */   public static String applyOverString(String action, String algorithm, String mode, String key, boolean useRandomIVs, String value) throws MuleEncryptionException {
/*  70 */     if (action.equals("encrypt")) {
/*  71 */       return encrypt(value, algorithm, mode, key, useRandomIVs);
/*     */     }
/*  73 */     return decrypt(value, algorithm, mode, key, useRandomIVs);
/*     */   }
/*     */ 
/*     */   
/*     */   private static String applyOverFileValue(String action, String algorithm, String mode, String key, boolean useRandomIVs, String value) throws MuleEncryptionException {
/*  78 */     if (action.equals("encrypt")) {
/*  79 */       return "![" + encrypt(value, algorithm, mode, key, useRandomIVs) + "]";
/*     */     }
/*  81 */     Matcher m = encryptPattern.matcher(value);
/*  82 */     if (m.find())
/*     */     {
/*  84 */       return decrypt(m.group(1), algorithm, mode, key, useRandomIVs);
/*     */     }
/*  86 */     return value;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static String removeComment(String line) {
/*  92 */     StringBuilder result = new StringBuilder();
/*  93 */     boolean opened = false;
/*  94 */     for (char c : line.toCharArray()) {
/*  95 */       if (c == '#' && !opened) {
/*  96 */         return result.toString();
/*     */       }
/*  98 */       result.append(c);
/*  99 */       if (c == '"') {
/* 100 */         if (opened) {
/* 101 */           return result.toString();
/*     */         }
/* 103 */         opened = true;
/*     */       } 
/*     */     } 
/*     */     
/* 107 */     return result.toString();
/*     */   }
/*     */   
/*     */   private static String getComment(String line) {
/* 111 */     String result = "";
/* 112 */     boolean startedComment = false;
/* 113 */     boolean openedValue = false;
/* 114 */     for (char c : line.toCharArray()) {
/* 115 */       if (c == '#' && !openedValue) {
/* 116 */         startedComment = true;
/*     */       }
/*     */       
/* 119 */       if (c == '"') {
/* 120 */         openedValue = !openedValue;
/*     */       }
/*     */       
/* 123 */       if (startedComment) {
/* 124 */         result = result + c;
/*     */       }
/*     */     } 
/* 127 */     return result;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static void processFileLine(String line, BufferedWriter writer, String action, String algorithm, String mode, String key, boolean useRandomIVs, String separator, boolean space) throws IOException, MuleEncryptionException {
/* 133 */     String comments = getComment(line);
/* 134 */     line = removeComment(line);
/* 135 */     if (!line.contains(separator)) {
/* 136 */       writer.write(comments);
/*     */       return;
/*     */     } 
/* 139 */     String in = line.split(separator)[0];
/* 140 */     writer.write(in + separator);
/* 141 */     String value = line.substring(in.length() + 1).trim();
/* 142 */     if (value.length() > 0) {
/* 143 */       if (space) {
/* 144 */         writer.write(" ");
/*     */       }
/* 146 */       String[] splitted = value.split("\"");
/* 147 */       if (splitted.length == 0) {
/* 148 */         writer.write("\"" + applyOverFileValue(action, algorithm, mode, key, useRandomIVs, "") + '"');
/* 149 */       } else if (splitted.length == 1) {
/* 150 */         writer.write(applyOverFileValue(action, algorithm, mode, key, useRandomIVs, value));
/*     */       } else {
/* 152 */         writer.write("\"" + applyOverFileValue(action, algorithm, mode, key, useRandomIVs, splitted[1]) + '"');
/*     */       } 
/*     */     } 
/* 155 */     if (comments.length() > 0) {
/* 156 */       writer.write(" " + comments);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void applyOverFile(String action, String algorithm, String mode, String key, boolean useRandomIVs, String inputFilePath, String outputFilePath) throws IOException {
/* 163 */     StringBuilder errorsFound = new StringBuilder();
/*     */     
/* 165 */     try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(outputFilePath, new String[0]), new java.nio.file.OpenOption[0])) {
/* 166 */       Files.lines(Paths.get(inputFilePath, new String[0])).forEach(line -> {
/*     */             try {
/*     */               if (line.trim().length() == 0) {
/*     */                 writer.write("\n");
/*     */                 
/*     */                 return;
/*     */               } 
/*     */               
/*     */               if (inputFilePath.endsWith(".yaml")) {
/*     */                 processFileLine(line, writer, action, algorithm, mode, key, useRandomIVs, ":", true);
/*     */               } else {
/*     */                 processFileLine(line, writer, action, algorithm, mode, key, useRandomIVs, "=", false);
/*     */               } 
/*     */               writer.write("\n");
/* 180 */             } catch (MuleEncryptionException e) {
/*     */               errorsFound.append(e.getCause().getMessage()).append(System.lineSeparator());
/* 182 */             } catch (IOException e) {
/*     */               errorsFound.append(e.getMessage()).append(System.lineSeparator());
/*     */             } 
/*     */           });
/*     */     } 
/*     */     
/* 188 */     if (errorsFound.length() != 0)
/* 189 */       throw new IOException(errorsFound.toString()); 
/*     */   }
/*     */   
/*     */   public static void applyHoleFile(String action, String algorithm, String mode, String key, boolean useRandomIVs, String inputFilePath, String outputFilePath) throws IOException, MuleEncryptionException {
/*     */     byte[] result;
/* 194 */     File inputFile = new File(inputFilePath);
/* 195 */     InputStream stream = new FileInputStream(inputFile);
/* 196 */     byte[] bytes = IOUtils.toByteArray(stream);
/*     */     
/* 198 */     if (action.equals("encrypt")) {
/* 199 */       result = encrypt(bytes, algorithm, mode, key, useRandomIVs);
/*     */     } else {
/* 201 */       result = decrypt(bytes, algorithm, mode, key, useRandomIVs);
/*     */     } 
/* 203 */     FileUtils.writeByteArrayToFile(new File(outputFilePath), result);
/*     */   }
/*     */   
/*     */   private static void usage() {
/* 207 */     System.err.println("Usage:");
/* 208 */     System.err.println("\tjava -cp secure-properties-tool.jar com.mulesoft.tools.SecurePropertiesTool string <encrypt|decrypt> <algorithm> <mode> <key> <value> --use-random-iv [optional]");
/* 209 */     System.err.println("\tor");
/* 210 */     System.err.println("\tjava -cp secure-properties-tool.jar com.mulesoft.tools.SecurePropertiesTool file <encrypt|decrypt> <algorithm> <mode> <key> <input file> <output file> --use-random-iv [optional]");
/* 211 */     System.err.println("\tor");
/* 212 */     System.err.println("\tjava -cp secure-properties-tool.jar com.mulesoft.tools.SecurePropertiesTool file-level <encrypt|decrypt> <algorithm> <mode> <key> <input file> <output file> --use-random-iv [optional]");
/*     */   }
/*     */   
/*     */   private static boolean extractUseRandomIVArgument(String[] args) {
/* 216 */     if (args != null && args.length != 0) {
/* 217 */       return "--use-random-iv".equals(args[args.length - 1]);
/*     */     }
/* 219 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean validateArguments(String[] args) {
/* 223 */     if (args == null || args.length == 0) {
/* 224 */       return false;
/*     */     }
/* 226 */     boolean useRandomIVs = extractUseRandomIVArgument(args);
/*     */     
/* 228 */     int minArguments = useRandomIVs ? 7 : 6;
/* 229 */     if (args.length < minArguments) {
/* 230 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 234 */     String type = args[0];
/* 235 */     String action = args[1];
/* 236 */     String algorithm = args[2];
/* 237 */     String mode = args[3];
/*     */     
/* 239 */     if (!type.equals("string") && !type.equals("file") && !type.equals("file-level")) {
/* 240 */       return false;
/*     */     }
/* 242 */     if (!action.equals("encrypt") && !action.equals("decrypt")) {
/* 243 */       return false;
/*     */     }
/*     */     try {
/* 246 */       EncryptionAlgorithm.valueOf(algorithm);
/* 247 */     } catch (IllegalArgumentException e) {
/* 248 */       return false;
/*     */     } 
/*     */     
/*     */     try {
/* 252 */       EncryptionMode.valueOf(mode);
/* 253 */     } catch (IllegalArgumentException e) {
/* 254 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 258 */     if (type.equals("file") || type.equals("file-level")) {
/* 259 */       int i = useRandomIVs ? 8 : 7;
/* 260 */       if (args.length != i) {
/* 261 */         return false;
/*     */       }
/*     */       
/* 264 */       String input = args[5];
/* 265 */       String output = args[6];
/* 266 */       return ((input.endsWith(".yaml") && output.endsWith(".yaml")) || (input.endsWith(".properties") && output.endsWith(".properties")));
/*     */     } 
/* 268 */     int maxArgumentsLength = useRandomIVs ? 7 : 6;
/* 269 */     return (args.length == maxArgumentsLength);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/* 274 */     if (!validateArguments(args)) {
/* 275 */       System.err.println("Invalid arguments");
/* 276 */       usage();
/* 277 */       System.exit(1);
/*     */     } 
/*     */     
/*     */     try {
/* 281 */       boolean useRandomIVs = extractUseRandomIVArgument(args);
/*     */       
/* 283 */       String type = args[0];
/* 284 */       String action = args[1];
/* 285 */       String algorithm = args[2];
/* 286 */       String mode = args[3];
/* 287 */       String key = args[4];
/*     */       
/* 289 */       if (type.equals("string")) {
/* 290 */         System.out.println(applyOverString(action, algorithm, mode, key, useRandomIVs, args[5]));
/*     */       } else {
/* 292 */         String input = args[5];
/* 293 */         String output = args[6];
/* 294 */         if (type.equals("file")) {
/* 295 */           applyOverFile(action, algorithm, mode, key, useRandomIVs, input, output);
/*     */         } else {
/* 297 */           applyHoleFile(action, algorithm, mode, key, useRandomIVs, input, output);
/*     */         } 
/*     */       } 
/* 300 */     } catch (MuleEncryptionException e) {
/* 301 */       System.err.println(e.getCause().getMessage());
/* 302 */       System.exit(2);
/* 303 */     } catch (IOException e) {
/* 304 */       System.err.println(e.getMessage());
/* 305 */       System.exit(3);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/com/mulesoft/tools/SecurePropertiesTool.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */