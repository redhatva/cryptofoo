package org.apache.commons.io.filefilter;

import java.util.List;

public interface ConditionalFileFilter {
  void addFileFilter(IOFileFilter paramIOFileFilter);
  
  List getFileFilters();
  
  boolean removeFileFilter(IOFileFilter paramIOFileFilter);
  
  void setFileFilters(List paramList);
}


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/apache/commons/io/filefilter/ConditionalFileFilter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */