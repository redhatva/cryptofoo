/*    */ package org.apache.commons.io.filefilter;
/*    */ 
/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SizeFileFilter
/*    */   extends AbstractFileFilter
/*    */ {
/*    */   private long size;
/*    */   private boolean acceptLarger;
/*    */   
/*    */   public SizeFileFilter(long size) {
/* 55 */     this(size, true);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SizeFileFilter(long size, boolean acceptLarger) {
/* 68 */     if (size < 0L) {
/* 69 */       throw new IllegalArgumentException("The size must be non-negative");
/*    */     }
/* 71 */     this.size = size;
/* 72 */     this.acceptLarger = acceptLarger;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean accept(File file) {
/* 88 */     boolean smaller = (file.length() < this.size);
/* 89 */     return this.acceptLarger ? (!smaller) : smaller;
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/apache/commons/io/filefilter/SizeFileFilter.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.1.3
 */