package org.mule.encryption;

import org.mule.encryption.exception.MuleEncryptionException;

public interface Encrypter {
  byte[] decrypt(byte[] paramArrayOfbyte) throws MuleEncryptionException;
  
  byte[] encrypt(byte[] paramArrayOfbyte) throws MuleEncryptionException;
}


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/mule/encryption/Encrypter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */