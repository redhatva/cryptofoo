/*    */ package org.mule.encryption.jce;
/*    */ 
/*    */ import java.security.spec.AlgorithmParameterSpec;
/*    */ import javax.crypto.spec.IvParameterSpec;
/*    */ import javax.crypto.spec.PBEParameterSpec;
/*    */ import org.mule.encryption.key.EncryptionKeyFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JCEPbeEncrypter
/*    */   extends JCEEncrypter
/*    */ {
/*    */   public JCEPbeEncrypter(String transformation, EncryptionKeyFactory keyFactory) {
/* 24 */     this(transformation, null, keyFactory);
/*    */   }
/*    */   
/*    */   public JCEPbeEncrypter(String transformation, String provider, EncryptionKeyFactory keyFactory) {
/* 28 */     super(transformation, provider, keyFactory);
/*    */   }
/*    */ 
/*    */   
/*    */   protected AlgorithmParameterSpec getAlgorithmParameterSpec(IvParameterSpec ivParam) {
/* 33 */     return new PBEParameterSpec("12345678".getBytes(), 20, ivParam);
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/mule/encryption/jce/JCEPbeEncrypter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */