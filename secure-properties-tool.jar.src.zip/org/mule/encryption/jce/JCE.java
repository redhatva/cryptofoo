/*    */ package org.mule.encryption.jce;
/*    */ 
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import javax.crypto.Cipher;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JCE
/*    */ {
/*    */   public static boolean isJCEInstalled() {
/*    */     try {
/* 15 */       int maxKeyLen = Cipher.getMaxAllowedKeyLength("AES");
/* 16 */       return (maxKeyLen > 256);
/* 17 */     } catch (NoSuchAlgorithmException e) {
/* 18 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/mule/encryption/jce/JCE.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */