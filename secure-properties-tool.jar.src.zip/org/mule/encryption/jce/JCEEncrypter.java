/*     */ package org.mule.encryption.jce;
/*     */ 
/*     */ import java.security.InvalidAlgorithmParameterException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Key;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.NoSuchProviderException;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.spec.AlgorithmParameterSpec;
/*     */ import java.util.Arrays;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import org.mule.encryption.Encrypter;
/*     */ import org.mule.encryption.exception.MuleEncryptionException;
/*     */ import org.mule.encryption.exception.MuleInvalidAlgorithmConfigurationException;
/*     */ import org.mule.encryption.exception.MuleInvalidKeyException;
/*     */ import org.mule.encryption.key.EncryptionKeyFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JCEEncrypter
/*     */   implements Encrypter
/*     */ {
/*     */   private static final String INSTALL_JCE_MESSAGE = " You need to install the Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files";
/*     */   private static final String ECB = "ECB";
/*     */   private final String provider;
/*     */   private final String transformation;
/*     */   private final EncryptionKeyFactory keyFactory;
/*     */   private final boolean useRandomIV;
/*     */   
/*     */   public JCEEncrypter(String transformation, EncryptionKeyFactory keyFactory) {
/*  46 */     this(transformation, (String)null, keyFactory);
/*     */   }
/*     */   
/*     */   public JCEEncrypter(String transformation, String provider, EncryptionKeyFactory keyFactory) {
/*  50 */     this(transformation, provider, keyFactory, false);
/*     */   }
/*     */   
/*     */   public JCEEncrypter(String transformation, EncryptionKeyFactory keyFactory, boolean useRandomIV) {
/*  54 */     this(transformation, null, keyFactory, useRandomIV);
/*     */   }
/*     */   
/*     */   public JCEEncrypter(String transformation, String provider, EncryptionKeyFactory keyFactory, boolean useRandomIV) {
/*  58 */     this.transformation = transformation;
/*  59 */     this.provider = provider;
/*  60 */     this.keyFactory = keyFactory;
/*  61 */     this.useRandomIV = useRandomIV;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] decrypt(byte[] content) throws MuleEncryptionException {
/*  66 */     return runCipher(content, this.keyFactory.decryptionKey(), 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] encrypt(byte[] content) throws MuleEncryptionException {
/*  71 */     return runCipher(content, this.keyFactory.encryptionKey(), 1);
/*     */   }
/*     */   
/*     */   protected AlgorithmParameterSpec getAlgorithmParameterSpec(IvParameterSpec ivParam) {
/*  75 */     return ivParam;
/*     */   }
/*     */ 
/*     */   
/*     */   private byte[] runCipher(byte[] content, Key key, int mode) throws MuleEncryptionException {
/*     */     try {
/*  81 */       Cipher cipher = getCipher();
/*  82 */       String[] cipherParts = this.transformation.split("/");
/*     */       
/*  84 */       if (cipherParts.length >= 2 && "ECB".equals(cipherParts[1])) {
/*     */         
/*  86 */         cipher.init(mode, key);
/*     */         
/*  88 */         return cipher.doFinal(content);
/*     */       } 
/*  90 */       SecureRandom secureRandom = new SecureRandom();
/*     */ 
/*     */       
/*  93 */       byte[] ivInByteArray = new byte[cipher.getBlockSize()];
/*  94 */       if (this.useRandomIV) {
/*  95 */         if (mode == 1) {
/*  96 */           secureRandom.nextBytes(ivInByteArray);
/*     */         } else {
/*  98 */           ivInByteArray = Arrays.copyOfRange(content, 0, ivInByteArray.length);
/*  99 */           content = Arrays.copyOfRange(content, ivInByteArray.length, content.length);
/*     */         } 
/*     */       } else {
/* 102 */         ivInByteArray = Arrays.copyOfRange(key.getEncoded(), 0, ivInByteArray.length);
/*     */       } 
/*     */       
/* 105 */       cipher.init(mode, key, getAlgorithmParameterSpec(new IvParameterSpec(ivInByteArray)), secureRandom);
/*     */       
/* 107 */       byte[] result = cipher.doFinal(content);
/*     */       
/* 109 */       if (mode == 1 && this.useRandomIV) {
/* 110 */         byte[] byteArrayToConcatEncryptedDataAndIV = new byte[ivInByteArray.length + result.length];
/*     */         
/* 112 */         System.arraycopy(ivInByteArray, 0, byteArrayToConcatEncryptedDataAndIV, 0, ivInByteArray.length);
/* 113 */         System.arraycopy(result, 0, byteArrayToConcatEncryptedDataAndIV, ivInByteArray.length, result.length);
/*     */         
/* 115 */         return byteArrayToConcatEncryptedDataAndIV;
/*     */       } 
/*     */       
/* 118 */       return result;
/*     */     
/*     */     }
/* 121 */     catch (InvalidAlgorithmParameterException e) {
/* 122 */       throw invalidAlgorithmConfigurationException(String.format("Wrong configuration for algorithm '%s'", new Object[] { this.transformation }), e);
/* 123 */     } catch (NoSuchAlgorithmException e) {
/* 124 */       throw invalidAlgorithmConfigurationException(String.format("Cipher '%s' not found", new Object[] { this.transformation }), e);
/* 125 */     } catch (NoSuchPaddingException e) {
/* 126 */       throw invalidAlgorithmConfigurationException(String.format("Invalid padding selected for cipher '%s'", new Object[] { this.transformation }), e);
/* 127 */     } catch (NoSuchProviderException e) {
/* 128 */       throw invalidAlgorithmConfigurationException(String.format("Provider '%s' not found", new Object[] { this.provider }), e);
/* 129 */     } catch (InvalidKeyException e) {
/* 130 */       throw handleInvalidKeyException(e, new String(key.getEncoded()));
/* 131 */     } catch (Exception e) {
/* 132 */       throw new MuleEncryptionException("Could not encrypt or decrypt the data.", e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Cipher getCipher() throws NoSuchPaddingException, NoSuchAlgorithmException, NoSuchProviderException {
/* 137 */     return (this.provider == null) ? Cipher.getInstance(this.transformation) : Cipher.getInstance(this.transformation, this.provider);
/*     */   }
/*     */   
/*     */   private MuleEncryptionException invalidAlgorithmConfigurationException(String message, Exception e) {
/* 141 */     if (!JCE.isJCEInstalled()) {
/* 142 */       message = message + " You need to install the Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy Files";
/*     */     }
/*     */     
/* 145 */     return (MuleEncryptionException)new MuleInvalidAlgorithmConfigurationException(message, e);
/*     */   }
/*     */   
/*     */   private MuleEncryptionException handleInvalidKeyException(InvalidKeyException e, String key) {
/* 149 */     String message = String.format("The key is invalid, please make sure it's of a supported size (actual is %s)", new Object[] { Integer.valueOf(key.length()) });
/* 150 */     return (MuleEncryptionException)new MuleInvalidKeyException(message, e);
/*     */   }
/*     */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/mule/encryption/jce/JCEEncrypter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */