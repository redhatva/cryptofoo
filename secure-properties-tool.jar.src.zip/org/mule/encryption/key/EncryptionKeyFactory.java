package org.mule.encryption.key;

import java.security.Key;

public interface EncryptionKeyFactory {
  Key encryptionKey();
  
  Key decryptionKey();
}


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/mule/encryption/key/EncryptionKeyFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */