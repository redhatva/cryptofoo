/*    */ package org.mule.encryption.key;
/*    */ 
/*    */ import java.security.Key;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface SymmetricKeyFactory
/*    */   extends EncryptionKeyFactory
/*    */ {
/*    */   default Key decryptionKey() {
/* 18 */     return encryptionKey();
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/mule/encryption/key/SymmetricKeyFactory.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */