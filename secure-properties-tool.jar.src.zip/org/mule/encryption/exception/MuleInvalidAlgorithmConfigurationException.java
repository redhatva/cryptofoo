/*    */ package org.mule.encryption.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MuleInvalidAlgorithmConfigurationException
/*    */   extends MuleEncryptionException
/*    */ {
/*    */   public MuleInvalidAlgorithmConfigurationException(String message, Exception cause) {
/* 12 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/mule/encryption/exception/MuleInvalidAlgorithmConfigurationException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */