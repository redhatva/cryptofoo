/*    */ package org.mule.encryption.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MuleEncryptionException
/*    */   extends Exception
/*    */ {
/*    */   public MuleEncryptionException(String message) {
/* 12 */     super(message);
/*    */   }
/*    */   
/*    */   public MuleEncryptionException(String message, Exception cause) {
/* 16 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/mule/encryption/exception/MuleEncryptionException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */