/*    */ package org.mule.encryption.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MuleInvalidKeyException
/*    */   extends MuleEncryptionException
/*    */ {
/*    */   public MuleInvalidKeyException(String message, Exception cause) {
/* 12 */     super(message, cause);
/*    */   }
/*    */ }


/* Location:              /Users/robert/Downloads/secure-properties-tool.jar!/org/mule/encryption/exception/MuleInvalidKeyException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */